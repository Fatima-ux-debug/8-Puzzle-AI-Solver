import tkinter as tk
import random
import time
import heapq
from collections import deque

GOAL = (1,2,3,4,5,6,7,8,0)

# ---------------- Utility ---------------- #

def is_solvable(state):
    inv = 0
    arr = [x for x in state if x != 0]
    for i in range(len(arr)):
        for j in range(i+1, len(arr)):
            if arr[i] > arr[j]:
                inv += 1
    return inv % 2 == 0


def random_state():
    while True:
        s = list(range(9))
        random.shuffle(s)
        s = tuple(s)
        if is_solvable(s) and s != GOAL:
            return s


def neighbors(state):
    res = []
    i = state.index(0)
    r, c = divmod(i, 3)

    for m in [(-1,0),(1,0),(0,-1),(0,1)]:
        nr, nc = r+m[0], c+m[1]
        if 0 <= nr < 3 and 0 <= nc < 3:
            j = nr*3 + nc
            s = list(state)
            s[i], s[j] = s[j], s[i]
            res.append(tuple(s))
    return res


def manhattan(state):
    d = 0
    for i in range(9):
        if state[i] != 0:
            gi = GOAL.index(state[i])
            x1,y1 = divmod(i,3)
            x2,y2 = divmod(gi,3)
            d += abs(x1-x2)+abs(y1-y2)
    return d


def reconstruct(parent, end):
    path = []
    while end is not None:
        path.append(end)
        end = parent[end]
    return path[::-1]


# ---------------- Algorithms ---------------- #

def bfs(start):
    q = deque([start])
    parent = {start: None}
    nodes = 0

    while q:
        s = q.popleft()
        nodes += 1
        if s == GOAL:
            return reconstruct(parent, s), nodes
        for n in neighbors(s):
            if n not in parent:
                parent[n] = s
                q.append(n)


def dfs(start, limit=25):
    stack = [(start,0)]
    parent = {start: None}
    nodes = 0

    while stack:
        s, d = stack.pop()
        nodes += 1
        if s == GOAL:
            return reconstruct(parent, s), nodes
        if d < limit:
            for n in neighbors(s):
                if n not in parent:
                    parent[n] = s
                    stack.append((n, d+1))


def greedy(start):
    pq = [(manhattan(start), start)]
    parent = {start: None}
    nodes = 0

    while pq:
        _, s = heapq.heappop(pq)
        nodes += 1
        if s == GOAL:
            return reconstruct(parent, s), nodes
        for n in neighbors(s):
            if n not in parent:
                parent[n] = s
                heapq.heappush(pq, (manhattan(n), n))


def astar(start):
    pq = [(manhattan(start), 0, start)]
    parent = {start: None}
    cost = {start: 0}
    nodes = 0

    while pq:
        _, g, s = heapq.heappop(pq)
        nodes += 1
        if s == GOAL:
            return reconstruct(parent, s), nodes
        for n in neighbors(s):
            new_cost = g + 1
            if n not in cost or new_cost < cost[n]:
                cost[n] = new_cost
                parent[n] = s
                heapq.heappush(pq, (new_cost + manhattan(n), new_cost, n))


# ---------------- GUI ---------------- #

class PuzzleGUI:
    def __init__(self, root):
        self.root = root
        root.title("8 Puzzle – Animated Solver")

        self.state = random_state()
        self.labels = []

        for i in range(9):
            lbl = tk.Label(root, width=4, height=2,
                           font=("Arial", 22),
                           relief="solid")
            lbl.grid(row=i//3, column=i%3)
            self.labels.append(lbl)

        self.update(self.state)

        btns = [
            ("BFS", bfs),
            ("DFS", dfs),
            ("Greedy", greedy),
            ("A*", astar)
        ]

        for i,(name,func) in enumerate(btns):
            tk.Button(root, text=name, width=10,
                      command=lambda f=func,n=name: self.run(f,n)
                      ).grid(row=3+i//2, column=i%2, columnspan=1)

        tk.Button(root, text="Random Puzzle",
                  width=22, command=self.reset).grid(row=5, column=0, columnspan=3)

        self.info = tk.Label(root, text="", font=("Arial",10))
        self.info.grid(row=6, column=0, columnspan=3)

    def update(self, state):
        for i in range(9):
            self.labels[i]["text"] = "" if state[i]==0 else state[i]

    def animate(self, path, i=0):
        if i < len(path):
            self.update(path[i])
            self.root.after(500, self.animate, path, i+1)

    def run(self, func, name):
        start = time.time()
        path, nodes = func(self.state)
        elapsed = time.time() - start

        self.animate(path)
        self.info["text"] = (
            f"{name}\n"
            f"Steps: {len(path)-1}\n"
            f"Nodes Expanded: {nodes}\n"
            f"Time: {elapsed:.4f}s"
        )

    def reset(self):
        self.state = random_state()
        self.update(self.state)
        self.info["text"] = ""


root = tk.Tk()
PuzzleGUI(root)
root.mainloop()